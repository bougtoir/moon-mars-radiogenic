Dear Editors,

I am pleased to submit my manuscript, "From elemental abundance to exploration priority: radiogenic-resource prospectivity on the Moon and Mars," for consideration in Planetary and Space Science.

Planetary resource maps are often interpreted as if elemental enrichment and exploration priority were nearly interchangeable. This study shows that they are not. I introduce a preregistered, auditable framework that explicitly separates elemental source evidence, geological concentration context, and operational accessibility, and then asks how much each stage changes where we would actually choose to explore. Applying the same framework to public orbital data from the Moon and Mars creates a natural comparative test across two planetary bodies with markedly different geological histories.

The contrast is substantial. On the Moon, adding geological context leaves the elemental ranking almost intact (Spearman ρ = 0.967), whereas on Mars the same transition produces considerably greater rank reorganisation (ρ = 0.889). The difference becomes even more consequential when exploration is viewed through an ISRU lens: accessibility weighting changes top-decile membership by 63% on the Moon and 39% on Mars. These are not merely cartographic differences. They show quantitatively that the path from an elemental-abundance map to an actionable exploration target depends on both planetary geological context and operational constraints.

The methodological contribution is equally important. The analysis is performed on common 5° grids comprising 1,790 lunar and 2,468 Martian cells, while explicitly avoiding pseudo-resolution from combining coarse gamma-ray observations with finer geological data. Model dependence is propagated through 10,000 Dirichlet weight draws, allowing candidate regions to be evaluated by the stability of their exploration ranking rather than by a single arbitrarily weighted overlay. The principal Moon–Mars contrast also persists when the Martian water-equivalent-hydrogen layer is removed and when the analysis is repeated at 10° resolution.

I have deliberately kept the scientific claims narrower than the maps might tempt one to make. The manuscript does not claim discovery of deposits, reserves, mineable resources, or Martian uranium concentrations. The Moon includes direct orbital uranium information, whereas Mars has no verified orbital uranium map and is therefore represented by thorium with potassium as contextual radiogenic-source evidence. Candidate regions are reported strictly as priorities for higher-resolution follow-up. Likewise, the stronger Martian rank response is interpreted as a property of the specified observational framework, not as proof that geological reworking was physically stronger on Mars.

I believe this distinction is precisely why the study is relevant to Planetary and Space Science. As planetary exploration increasingly moves from compositional mapping toward resource assessment and mission prioritisation, there is a growing need for methods that make the inferential steps between those stages explicit, testable, and uncertainty-aware. The framework developed here is not specific to uranium or even to radiogenic elements; it provides a transferable way to ask when an orbital compositional anomaly should — and should not — become an exploration target.

All input data are from public mission archives, provenance is recorded in a SHA-256 manifest, and the complete analysis pipeline is reproducible. Null and inconvenient findings are retained, including the near-preservation of lunar elemental ranks and the limitations imposed by missing Martian uranium observations.

I hope the Editors will find that this work offers both a new comparative result for the Moon and Mars and a practical methodological contribution to planetary resource prospectivity and exploration planning. I would be grateful for the opportunity to have it considered by Planetary and Space Science.

Sincerely,
Tatsuki Onishi
[Affiliation]
[ORCID]
[Corresponding email]
