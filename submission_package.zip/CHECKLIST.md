# Submission checklist (PSS)

- [x] manuscript_clean.docx (full-length, OMML equations, TNR 12pt)
- [x] manuscript_inline_figures.docx (figures embedded, 10pt captions)
- [x] supplement.docx (Tables S1–S3, Figures S1–S2, QC)
- [x] Figures 1–7 + Figures S1–S2 (PNG, >=300 dpi)
- [x] Tables 1–4 in main text; Table S1–S3 in supplement
- [x] Cover letter (canonical, author fields left for owner)
- [x] Highlights (5 bullets)
- [x] Data availability statement
- [ ] Author affiliation / ORCID / corresponding email (owner)
- [ ] Suggested reviewers (owner)
