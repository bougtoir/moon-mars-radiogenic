# Phase 23 QC diagnostics

## Moon (1790 cells)
- Moran-like I(C_integrated) = 0.911 over 6716 neighbour pairs (7.5° adjacency)
- Moran-like I(A_element) = 0.934 over 6716 neighbour pairs (7.5° adjacency)
- Moran-like I(rank_sd) = 0.481 over 6716 neighbour pairs (7.5° adjacency)
- Moran-like I(u_ppm) = 0.955 over 6716 neighbour pairs (7.5° adjacency)
- columns with missing values: {'elev_m': 2, 'slope_deg': 2, 'rough_m': 2, 'E_slope': 2, 'E_rough': 2, 'A': 2}
## Mars (2592 cells)
- Moran-like I(C_integrated) = 0.508 over 27072 neighbour pairs (7.5° adjacency)
- Moran-like I(A_element) = 0.198 over 20363 neighbour pairs (7.5° adjacency)
- Moran-like I(rank_sd) = 0.154 over 20363 neighbour pairs (7.5° adjacency)
- Moran-like I(th_ppm) = 0.200 over 20363 neighbour pairs (7.5° adjacency)
- columns with missing values: {'th_wt': 124, 'th_sig': 124, 'k_wt': 17, 'k_sig': 17, 'th_ppm': 124, 'k_ppm': 17, 'kvsth': 138, 'E_th': 124, 'E_k': 17, 'S': 124, 'A_element': 124, 'rank_mean': 124, 'rank_sd': 124, 'U_model': 124, 'VOI': 124}

## Declared checks
- Layer Moran I ranges ~0.15–0.96 → strong spatial autocorrelation; per-cell inferential p-values would be anti-conservative. We therefore rely on set-overlap metrics (Jaccard), rank correlations and resampling, as protocolled.
- Lunar T domain is near-flat (limited dynamic range of basin/crater fractions at 5°) — flagged in LIMITATIONS.