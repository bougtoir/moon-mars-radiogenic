All inputs are public mission archives (NASA PDS / USGS). Every raw file's source URL,
licence and SHA-256 checksum is recorded in metadata/DATA_MANIFEST.csv and
metadata/DATA_PROVENANCE.md. Analysis code, derived tables and figures are in the
public companion repository (reproduction-only scope). Raw rasters are omitted for
size reasons and are exactly recoverable via the manifest.
